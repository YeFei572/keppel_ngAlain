import { Component } from '@angular/core';

@Component({
  selector: 'app-guard-admin',
  template: `
    <p>这是一个admin页面</p>
  `,
})
export class GuardAdminComponent {}
